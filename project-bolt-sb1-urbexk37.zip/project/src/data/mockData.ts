import { Athlete, PhysicalData, FunctionalData, PsychologicalData, PerformanceData } from '../types/athlete';

export const mockAthletes: Athlete[] = [
  {
    id: '1',
    name: 'Алексей Петров',
    age: 16,
    gender: 'male',
    sport: 'Легкая атлетика',
    position: 'Спринт',
    sportsLevel: 'first_class',
    trainingExperience: 4,
    createdAt: new Date('2024-01-15'),
    updatedAt: new Date('2024-12-20')
  },
  {
    id: '2',
    name: 'Мария Иванова',
    age: 15,
    gender: 'female',
    sport: 'Плавание',
    position: 'Вольный стиль',
    sportsLevel: 'candidate',
    trainingExperience: 3,
    createdAt: new Date('2024-02-10'),
    updatedAt: new Date('2024-12-18')
  },
  {
    id: '3',
    name: 'Дмитрий Сидоров',
    age: 17,
    gender: 'male',
    sport: 'Футбол',
    position: 'Полузащитник',
    sportsLevel: 'amateur',
    trainingExperience: 5,
    createdAt: new Date('2024-01-20'),
    updatedAt: new Date('2024-12-19')
  },
  {
    id: '4',
    name: 'Анна Козлова',
    age: 16,
    gender: 'female',
    sport: 'Спортивная гимнастика',
    position: 'Многоборье',
    sportsLevel: 'master',
    trainingExperience: 8,
    createdAt: new Date('2024-03-05'),
    updatedAt: new Date('2024-12-17')
  },
  {
    id: '5',
    name: 'Игорь Волков',
    age: 18,
    gender: 'male',
    sport: 'Баскетбол',
    position: 'Центровой',
    sportsLevel: 'first_class',
    trainingExperience: 6,
    createdAt: new Date('2024-02-20'),
    updatedAt: new Date('2024-12-16')
  },
  {
    id: '6',
    name: 'Елена Смирнова',
    age: 17,
    gender: 'female',
    sport: 'Настольный теннис',
    position: 'Одиночные игры',
    sportsLevel: 'candidate',
    trainingExperience: 5,
    createdAt: new Date('2024-03-10'),
    updatedAt: new Date('2024-12-15')
  },
  {
    id: '7',
    name: 'Андрей Морозов',
    age: 18,
    gender: 'male',
    sport: 'Биатлон',
    position: 'Спринт/Гонка преследования',
    sportsLevel: 'first_class',
    trainingExperience: 7,
    createdAt: new Date('2024-01-25'),
    updatedAt: new Date('2024-12-14')
  },
  {
    id: '8',
    name: 'Ксения Попова',
    age: 16,
    gender: 'female',
    sport: 'Дзюдо',
    position: 'Весовая категория до 57 кг',
    sportsLevel: 'candidate',
    trainingExperience: 4,
    createdAt: new Date('2024-02-15'),
    updatedAt: new Date('2024-12-13')
  },
  {
    id: '9',
    name: 'Максим Федоров',
    age: 17,
    gender: 'male',
    sport: 'Волейбол',
    position: 'Связующий',
    sportsLevel: 'amateur',
    trainingExperience: 6,
    createdAt: new Date('2024-03-01'),
    updatedAt: new Date('2024-12-12')
  },
  {
    id: '10',
    name: 'Виктория Лебедева',
    age: 15,
    gender: 'female',
    sport: 'Художественная гимнастика',
    position: 'Индивидуальное многоборье',
    sportsLevel: 'master',
    trainingExperience: 9,
    createdAt: new Date('2024-01-30'),
    updatedAt: new Date('2024-12-11')
  },
  {
    id: '11',
    name: 'Роман Кузнецов',
    age: 18,
    gender: 'male',
    sport: 'Борьба вольная',
    position: 'Весовая категория до 74 кг',
    sportsLevel: 'first_class',
    trainingExperience: 8,
    createdAt: new Date('2024-02-05'),
    updatedAt: new Date('2024-12-10')
  },
  {
    id: '12',
    name: 'Алина Васильева',
    age: 16,
    gender: 'female',
    sport: 'Гандбол',
    position: 'Правый крайний',
    sportsLevel: 'candidate',
    trainingExperience: 5,
    createdAt: new Date('2024-03-15'),
    updatedAt: new Date('2024-12-09')
  }
];

export const mockPhysicalData: PhysicalData[] = [
  {
    id: '1',
    athleteId: '1',
    bodyLength: 178,
    bodyLengthSitting: 92,
    bodyMass: 68,
    armSpan: 182,
    legLength: 92,
    shoulderWidth: 45,
    chestCircumference: 98,
    waistCircumference: 76,
    hipCircumference: 88,
    thighCircumference: 58,
    calfCircumference: 38,
    armCircumference: 32,
    forearmCircumference: 28,
    neckCircumference: 38,
    bmiIndex: 21.5,
    skibinskiIndex: 58.2,
    pignetIndex: 42,
    erisman: 22,
    recordedAt: new Date('2024-12-15')
  }
];

export const mockFunctionalData: FunctionalData[] = [
  {
    id: '1',
    athleteId: '1',
    vo2Max: 58.2,
    restingHeartRate: 52,
    vitalCapacity: 4500,
    breathHoldInhale: 65,
    breathHoldExhale: 35,
    rufierIndex: 4.2,
    martineTest: 2.5,
    orthostatic: 12,
    harvardStepTest: 85,
    pwc150: 1100,
    pwc170: 1250,
    sprint30m: 4.2,
    sprint60m: 7.8,
    sprint100m: 11.5,
    standingLongJump: 265,
    verticalJump: 65,
    handGripStrength: 45,
    backStrength: 125,
    legStrength: 180,
    pullUpsBar: 15,
    hangTime: 45,
    sitUps: 52,
    pushUps: 35,
    plankTime: 180,
    sitAndReach: 28,
    shoulderFlexibility: 15,
    spineFlexibility: 25,
    shuttleRun4x9: 8.8,
    balanceTest: 25,
    reactionTime: 180,
    cooper6min: 1450,
    cooper12min: 2850,
    run500m: 1.25,
    run800m: 2.15,
    run1000m: 3.15,
    run1500m: 5.20,
    run3000m: 11.45,
    recordedAt: new Date('2024-12-15')
  }
];

export const mockPsychologicalData: PsychologicalData[] = [
  {
    id: '1',
    athleteId: '1',
    competitiveAnxiety: 6,
    selfConfidence: 8,
    motivation: 9,
    goalOrientation: 8,
    stressResistance: 7,
    emotionalControl: 7,
    focus: 9,
    resilience: 8,
    teamwork: 6,
    leadership: 7,
    communication: 7,
    adaptability: 8,
    competitiveness: 10,
    riskTaking: 8,
    recordedAt: new Date('2024-12-10')
  }
];

export const mockPerformanceData: PerformanceData[] = [
  {
    id: '1',
    athleteId: '1',
    competitionName: 'Региональный чемпионат',
    result: 11.15,
    ranking: 2,
    totalParticipants: 24,
    date: new Date('2024-11-15'),
    notes: 'Хороший старт, нужно работать над финишем'
  },
  {
    id: '2',
    athleteId: '2',
    competitionName: 'Открытое первенство города',
    result: 26.8,
    ranking: 1,
    totalParticipants: 18,
    date: new Date('2024-12-01'),
    notes: 'Отличная техника, личный рекорд'
  }
];