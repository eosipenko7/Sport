import React, { useState } from 'react';
import { TrendingUp, BarChart3, PieChart, Target, Brain, Activity, AlertTriangle } from 'lucide-react';
import { mockAthletes, mockPhysicalData, mockFunctionalData, mockPsychologicalData } from '../../data/mockData';
import { PredictionModel } from '../../types/athlete';

export default function Analytics() {
  const [selectedAthleteId, setSelectedAthleteId] = useState(mockAthletes[0]?.id || '');
  
  // Мок данных прогнозирования
  const mockPrediction: PredictionModel = {
    athleteId: selectedAthleteId,
    predictedPerformance: 85.7,
    confidence: 0.89,
    keyFactors: [
      { factor: 'VO2 Max', impact: 0.8, category: 'functional' },
      { factor: 'Мотивация', impact: 0.7, category: 'psychological' },
      { factor: 'Время спринта', impact: -0.6, category: 'functional' },
      { factor: 'Стрессоустойчивость', impact: 0.5, category: 'psychological' },
      { factor: 'Мышечная масса', impact: 0.4, category: 'physical' }
    ],
    recommendations: [
      'Увеличить объем аэробных тренировок для улучшения VO2 Max',
      'Работать над техникой спринта для снижения времени',
      'Включить психологические тренинги для развития стрессоустойчивости',
      'Поддерживать высокий уровень мотивации через постановку целей'
    ]
  };

  const selectedAthlete = mockAthletes.find(a => a.id === selectedAthleteId);
  
  const getFactorColor = (category: string) => {
    switch (category) {
      case 'physical': return 'text-blue-600 bg-blue-100';
      case 'functional': return 'text-green-600 bg-green-100';
      case 'psychological': return 'text-purple-600 bg-purple-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getFactorIcon = (category: string) => {
    switch (category) {
      case 'physical': return Activity;
      case 'functional': return BarChart3;
      case 'psychological': return Brain;
      default: return Target;
    }
  };

  const getImpactColor = (impact: number) => {
    if (impact > 0.6) return 'text-green-600';
    if (impact > 0.3) return 'text-yellow-600';
    if (impact < -0.3) return 'text-red-600';
    return 'text-gray-600';
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Аналитика и прогнозирование</h2>
      </div>

      {/* Выбор спортсмена */}
      <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Выберите спортсмена для анализа
        </label>
        <select
          value={selectedAthleteId}
          onChange={(e) => setSelectedAthleteId(e.target.value)}
          className="w-full md:w-1/3 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors duration-200"
        >
          {mockAthletes.map(athlete => (
            <option key={athlete.id} value={athlete.id}>
              {athlete.name} - {athlete.sport}
            </option>
          ))}
        </select>
      </div>

      {selectedAthlete && (
        <>
          {/* Карточки метрик */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Прогноз результата</p>
                  <p className="text-2xl font-bold text-blue-600">{mockPrediction.predictedPerformance}%</p>
                </div>
                <TrendingUp className="text-blue-500 w-8 h-8" />
              </div>
              <div className="mt-3">
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-blue-500 h-2 rounded-full transition-all duration-500"
                    style={{ width: `${mockPrediction.predictedPerformance}%` }}
                  ></div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Уверенность модели</p>
                  <p className="text-2xl font-bold text-green-600">{Math.round(mockPrediction.confidence * 100)}%</p>
                </div>
                <Target className="text-green-500 w-8 h-8" />
              </div>
              <div className="mt-3">
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-green-500 h-2 rounded-full transition-all duration-500"
                    style={{ width: `${mockPrediction.confidence * 100}%` }}
                  ></div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Ключевых факторов</p>
                  <p className="text-2xl font-bold text-purple-600">{mockPrediction.keyFactors.length}</p>
                </div>
                <BarChart3 className="text-purple-500 w-8 h-8" />
              </div>
              <p className="text-xs text-gray-500 mt-2">Анализируемые параметры</p>
            </div>

            <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Рекомендаций</p>
                  <p className="text-2xl font-bold text-orange-600">{mockPrediction.recommendations.length}</p>
                </div>
                <AlertTriangle className="text-orange-500 w-8 h-8" />
              </div>
              <p className="text-xs text-gray-500 mt-2">Для улучшения результатов</p>
            </div>
          </div>

          {/* Ключевые факторы влияния */}
          <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
            <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
              <Target className="w-5 h-5 text-blue-500" />
              Ключевые факторы влияния на результат
            </h3>
            
            <div className="space-y-4">
              {mockPrediction.keyFactors.map((factor, index) => {
                const Icon = getFactorIcon(factor.category);
                const impactPercent = Math.abs(factor.impact * 100);
                
                return (
                  <div key={index} className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors duration-200">
                    <div className={`p-2 rounded-lg ${getFactorColor(factor.category)}`}>
                      <Icon size={20} />
                    </div>
                    
                    <div className="flex-1">
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-medium text-gray-900">{factor.factor}</span>
                        <span className={`font-semibold ${getImpactColor(factor.impact)}`}>
                          {factor.impact > 0 ? '+' : ''}{Math.round(factor.impact * 100)}%
                        </span>
                      </div>
                      
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className={`h-2 rounded-full transition-all duration-500 ${
                            factor.impact > 0 ? 'bg-green-500' : 'bg-red-500'
                          }`}
                          style={{ width: `${impactPercent}%` }}
                        ></div>
                      </div>
                    </div>
                    
                    <span className={`px-2 py-1 text-xs rounded-full font-medium ${getFactorColor(factor.category)}`}>
                      {factor.category === 'physical' ? 'Физич.' : 
                       factor.category === 'functional' ? 'Функц.' : 'Психол.'}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Рекомендации для тренировочного процесса */}
          <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
            <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-orange-500" />
              Рекомендации для коррекции тренировочного процесса
            </h3>
            
            <div className="space-y-3">
              {mockPrediction.recommendations.map((recommendation, index) => (
                <div key={index} className="flex items-start gap-3 p-4 bg-orange-50 rounded-lg border border-orange-100">
                  <div className="flex-shrink-0 mt-0.5">
                    <div className="w-6 h-6 bg-orange-500 text-white rounded-full flex items-center justify-center text-xs font-semibold">
                      {index + 1}
                    </div>
                  </div>
                  <p className="text-gray-700 leading-relaxed">{recommendation}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Визуализация данных */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Динамика развития</h3>
              <div className="h-64 bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg flex items-center justify-center">
                <div className="text-center">
                  <TrendingUp size={48} className="text-blue-400 mx-auto mb-2" />
                  <p className="text-gray-600">График прогресса по времени</p>
                  <p className="text-sm text-gray-500 mt-1">Показатели за последние 6 месяцев</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Сравнение с нормативами</h3>
              <div className="h-64 bg-gradient-to-br from-green-50 to-green-100 rounded-lg flex items-center justify-center">
                <div className="text-center">
                  <PieChart size={48} className="text-green-400 mx-auto mb-2" />
                  <p className="text-gray-600">Соответствие возрастным нормам</p>
                  <p className="text-sm text-gray-500 mt-1">По категориям подготовленности</p>
                </div>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}