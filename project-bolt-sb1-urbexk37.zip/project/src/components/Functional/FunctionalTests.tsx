import React, { useState } from 'react';
import { Save, User, Heart, Zap, Target, Activity, Timer, HelpCircle, Play, Pause, RotateCcw } from 'lucide-react';
import { mockAthletes } from '../../data/mockData';
import { FunctionalData, FunctionalTestSession } from '../../types/athlete';
import { functionalTestInstructions } from '../../data/testInstructions';

export default function FunctionalTests() {
  const [selectedAthleteId, setSelectedAthleteId] = useState('');
  const [showInstructions, setShowInstructions] = useState<string | null>(null);
  const [activeTest, setActiveTest] = useState<string | null>(null);
  const [testSession, setTestSession] = useState<Partial<FunctionalTestSession> | null>(null);
  const [timer, setTimer] = useState(0);
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  
  const [formData, setFormData] = useState<Partial<FunctionalData>>({
    vo2Max: 0,
    restingHeartRate: 0,
    vitalCapacity: 0,
    breathHoldInhale: 0,
    breathHoldExhale: 0,
    rufierIndex: 0,
    martineTest: 0,
    orthostatic: 0,
    harvardStepTest: 0,
    pwc150: 0,
    pwc170: 0,
    sprint30m: 0,
    sprint60m: 0,
    sprint100m: 0,
    standingLongJump: 0,
    verticalJump: 0,
    handGripStrength: 0,
    backStrength: 0,
    legStrength: 0,
    pullUpsBar: 0,
    hangTime: 0,
    sitUps: 0,
    pushUps: 0,
    plankTime: 0,
    sitAndReach: 0,
    shoulderFlexibility: 0,
    spineFlexibility: 0,
    shuttleRun4x9: 0,
    balanceTest: 0,
    reactionTime: 0,
    cooper6min: 0,
    cooper12min: 0,
    run500m: 0,
    run800m: 0,
    run1000m: 0,
    run1500m: 0,
    run3000m: 0
  });

  // Таймер для функциональных проб
  React.useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isTimerRunning) {
      interval = setInterval(() => {
        setTimer(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isTimerRunning]);

  const startTimer = () => setIsTimerRunning(true);
  const pauseTimer = () => setIsTimerRunning(false);
  const resetTimer = () => {
    setIsTimerRunning(false);
    setTimer(0);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Сохранение функциональных данных:', { athleteId: selectedAthleteId, ...formData });
  };

  // Валидация ввода с ограничениями
  const validateInput = (key: string, value: number) => {
    const limits: Record<string, { min: number; max: number }> = {
      sprint30m: { min: 3.0, max: 8.0 },
      sprint60m: { min: 6.0, max: 15.0 },
      sprint100m: { min: 10.0, max: 20.0 },
      shuttleRun4x9: { min: 7.0, max: 15.0 },
      run500m: { min: 1.0, max: 3.0 },
      run800m: { min: 1.5, max: 5.0 },
      run1000m: { min: 2.5, max: 6.0 },
      run1500m: { min: 4.0, max: 10.0 },
      run3000m: { min: 9.0, max: 20.0 },
      cooper6min: { min: 800, max: 2000 },
      cooper12min: { min: 1500, max: 4000 },
      restingHeartRate: { min: 40, max: 100 },
      vo2Max: { min: 30, max: 80 },
      vitalCapacity: { min: 2000, max: 7000 },
      breathHoldInhale: { min: 10, max: 120 },
      breathHoldExhale: { min: 5, max: 60 }
    };

    const limit = limits[key];
    if (limit && (value < limit.min || value > limit.max)) {
      alert(`Значение для ${key} должно быть между ${limit.min} и ${limit.max}`);
      return false;
    }
    return true;
  };

  const handleInputChange = (key: string, value: string) => {
    const numValue = parseFloat(value) || 0;
    if (validateInput(key, numValue)) {
      setFormData(prev => ({ ...prev, [key]: numValue }));
    }
  };

  const testGroups = [
    {
      title: 'Кардиореспираторные показатели',
      icon: Heart,
      color: 'text-red-500',
      fields: [
        { key: 'vo2Max', label: 'VO2 Max', unit: 'мл/кг/мин', min: 30, max: 80 },
        { key: 'restingHeartRate', label: 'ЧСС покоя', unit: 'уд/мин', min: 40, max: 100 },
        { key: 'vitalCapacity', label: 'ЖЕЛ', unit: 'мл', min: 2000, max: 7000 },
        { key: 'breathHoldInhale', label: 'Задержка дыхания на вдохе (Штанге)', unit: 'сек', instruction: 'breathHoldInhale', min: 10, max: 120 },
        { key: 'breathHoldExhale', label: 'Задержка дыхания на выдохе (Генча)', unit: 'сек', instruction: 'breathHoldExhale', min: 5, max: 60 }
      ]
    },
    {
      title: 'Функциональные пробы',
      icon: Activity,
      color: 'text-blue-500',
      fields: [
        { key: 'rufierIndex', label: 'Проба Руфье', unit: 'у.е.', instruction: 'rufierTest', interactive: true },
        { key: 'martineTest', label: 'Проба Мартине', unit: 'мин', instruction: 'martineTest', interactive: true },
        { key: 'orthostatic', label: 'Ортостатическая проба', unit: 'уд/мин' },
        { key: 'harvardStepTest', label: 'Гарвардский степ-тест', unit: 'индекс', instruction: 'harvardStepTest', interactive: true },
        { key: 'pwc150', label: 'PWC150 (для детей)', unit: 'кгм/мин', instruction: 'pwc150' },
        { key: 'pwc170', label: 'PWC170', unit: 'кгм/мин' }
      ]
    },
    {
      title: 'Скоростно-силовые качества',
      icon: Zap,
      color: 'text-yellow-500',
      fields: [
        { key: 'sprint30m', label: 'Бег 30м', unit: 'сек', min: 3.0, max: 8.0 },
        { key: 'sprint60m', label: 'Бег 60м', unit: 'сек', min: 6.0, max: 15.0 },
        { key: 'sprint100m', label: 'Бег 100м', unit: 'сек', min: 10.0, max: 20.0 },
        { key: 'standingLongJump', label: 'Прыжок в длину с места', unit: 'см' },
        { key: 'verticalJump', label: 'Прыжок вверх', unit: 'см' }
      ]
    },
    {
      title: 'Силовые качества',
      icon: Target,
      color: 'text-green-500',
      fields: [
        { key: 'handGripStrength', label: 'Сила кисти', unit: 'кг' },
        { key: 'backStrength', label: 'Сила спины', unit: 'кг' },
        { key: 'legStrength', label: 'Сила ног', unit: 'кг' }
      ]
    },
    {
      title: 'Силовая выносливость',
      icon: Timer,
      color: 'text-purple-500',
      fields: [
        { key: 'pullUpsBar', label: 'Подтягивание в висе на перекладине', unit: 'раз', instruction: 'pullUpsBar' },
        { key: 'hangTime', label: 'Вис на согнутых руках', unit: 'сек' },
        { key: 'sitUps', label: 'Поднимание туловища из положения лежа на спине', unit: 'раз/мин' },
        { key: 'pushUps', label: 'Сгибание-разгибание рук в упоре лежа', unit: 'раз', instruction: 'pushUps' },
        { key: 'plankTime', label: 'Планка', unit: 'сек' }
      ]
    },
    {
      title: 'Гибкость',
      icon: Activity,
      color: 'text-indigo-500',
      fields: [
        { key: 'sitAndReach', label: 'Наклон вперед из положения сидя', unit: 'см' },
        { key: 'shoulderFlexibility', label: 'Подвижность плечевых суставов', unit: 'см' },
        { key: 'spineFlexibility', label: 'Гибкость позвоночника', unit: 'см' }
      ]
    },
    {
      title: 'Координация и ловкость',
      icon: Target,
      color: 'text-pink-500',
      fields: [
        { key: 'shuttleRun4x9', label: 'Челночный бег 4×9м', unit: 'сек', instruction: 'shuttleRun4x9', min: 7.0, max: 15.0 },
        { key: 'balanceTest', label: 'Проба Ромберга', unit: 'сек' },
        { key: 'reactionTime', label: 'Время реакции', unit: 'мс' }
      ]
    },
    {
      title: 'Выносливость',
      icon: Heart,
      color: 'text-orange-500',
      fields: [
        { key: 'cooper6min', label: '6-минутный бег', unit: 'м', instruction: 'cooper6min', min: 800, max: 2000 },
        { key: 'cooper12min', label: 'Тест Купера 12 мин', unit: 'м', min: 1500, max: 4000 },
        { key: 'run500m', label: 'Бег 500м', unit: 'мин:сек', min: 1.0, max: 3.0 },
        { key: 'run800m', label: 'Бег 800м', unit: 'мин:сек', min: 1.5, max: 5.0 },
        { key: 'run1000m', label: 'Бег 1000м', unit: 'мин:сек', min: 2.5, max: 6.0 },
        { key: 'run1500m', label: 'Бег 1500м', unit: 'мин:сек', min: 4.0, max: 10.0 },
        { key: 'run3000m', label: 'Бег 3000м', unit: 'мин:сек', min: 9.0, max: 20.0 }
      ]
    }
  ];

  const InstructionModal = ({ testKey }: { testKey: string }) => {
    const instruction = functionalTestInstructions[testKey];
    if (!instruction) return null;

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-xl max-w-2xl w-full max-h-[80vh] overflow-y-auto">
          <div className="p-6">
            <div className="flex justify-between items-start mb-4">
              <h3 className="text-xl font-bold text-gray-900">{instruction.name}</h3>
              <button
                onClick={() => setShowInstructions(null)}
                className="text-gray-400 hover:text-gray-600"
              >
                ✕
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <h4 className="font-semibold text-gray-800 mb-2">Описание:</h4>
                <p className="text-gray-600">{instruction.description}</p>
              </div>
              
              <div>
                <h4 className="font-semibold text-gray-800 mb-2">Необходимое оборудование:</h4>
                <ul className="list-disc list-inside text-gray-600">
                  {instruction.equipment.map((item, index) => (
                    <li key={index}>{item}</li>
                  ))}
                </ul>
              </div>
              
              <div>
                <h4 className="font-semibold text-gray-800 mb-2">Пошаговая инструкция:</h4>
                <ol className="list-decimal list-inside space-y-1 text-gray-600">
                  {instruction.steps.map((step, index) => (
                    <li key={index}>{step}</li>
                  ))}
                </ol>
              </div>
              
              {instruction.norms && (
                <div>
                  <h4 className="font-semibold text-gray-800 mb-2">Нормативы:</h4>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
                    <div className="bg-green-100 p-2 rounded text-center">
                      <div className="font-medium text-green-800">Отлично</div>
                      <div className="text-green-600">{instruction.norms.excellent}</div>
                    </div>
                    <div className="bg-blue-100 p-2 rounded text-center">
                      <div className="font-medium text-blue-800">Хорошо</div>
                      <div className="text-blue-600">{instruction.norms.good}</div>
                    </div>
                    <div className="bg-yellow-100 p-2 rounded text-center">
                      <div className="font-medium text-yellow-800">Средне</div>
                      <div className="text-yellow-600">{instruction.norms.average}</div>
                    </div>
                    <div className="bg-red-100 p-2 rounded text-center">
                      <div className="font-medium text-red-800">Ниже среднего</div>
                      <div className="text-red-600">{instruction.norms.belowAverage}</div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  };

  const InteractiveTestModal = ({ testKey }: { testKey: string }) => {
    const instruction = functionalTestInstructions[testKey];
    if (!instruction) return null;

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-xl max-w-3xl w-full max-h-[80vh] overflow-y-auto">
          <div className="p-6">
            <div className="flex justify-between items-start mb-4">
              <h3 className="text-xl font-bold text-gray-900">Проведение теста: {instruction.name}</h3>
              <button
                onClick={() => setActiveTest(null)}
                className="text-gray-400 hover:text-gray-600"
              >
                ✕
              </button>
            </div>
            
            <div className="space-y-6">
              {/* Таймер */}
              <div className="bg-gray-50 rounded-lg p-4 text-center">
                <div className="text-3xl font-mono font-bold text-gray-900 mb-4">
                  {formatTime(timer)}
                </div>
                <div className="flex justify-center gap-2">
                  <button
                    onClick={startTimer}
                    className="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 flex items-center gap-2"
                  >
                    <Play size={16} />
                    Старт
                  </button>
                  <button
                    onClick={pauseTimer}
                    className="px-4 py-2 bg-yellow-500 text-white rounded-lg hover:bg-yellow-600 flex items-center gap-2"
                  >
                    <Pause size={16} />
                    Пауза
                  </button>
                  <button
                    onClick={resetTimer}
                    className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 flex items-center gap-2"
                  >
                    <RotateCcw size={16} />
                    Сброс
                  </button>
                </div>
              </div>

              {/* Пошаговые инструкции */}
              <div>
                <h4 className="font-semibold text-gray-800 mb-3">Пошаговое выполнение:</h4>
                <div className="space-y-3">
                  {instruction.steps.map((step, index) => (
                    <div key={index} className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg">
                      <div className="w-6 h-6 bg-blue-500 text-white rounded-full flex items-center justify-center text-sm font-semibold flex-shrink-0">
                        {index + 1}
                      </div>
                      <p className="text-gray-700">{step}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Поля для ввода промежуточных данных */}
              {testKey === 'rufierTest' && (
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">P1 (покой)</label>
                    <input
                      type="number"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                      placeholder="уд/15сек"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">P2 (после нагрузки)</label>
                    <input
                      type="number"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                      placeholder="уд/15сек"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">P3 (восстановление)</label>
                    <input
                      type="number"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                      placeholder="уд/15сек"
                    />
                  </div>
                </div>
              )}

              {testKey === 'harvardStepTest' && (
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">ЧСС 60-90 сек (f1)</label>
                    <input
                      type="number"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                      placeholder="уд/мин"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">ЧСС 120-150 сек (f2)</label>
                    <input
                      type="number"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                      placeholder="уд/мин"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">ЧСС 180-210 сек (f3)</label>
                    <input
                      type="number"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                      placeholder="уд/мин"
                    />
                  </div>
                </div>
              )}

              <div className="flex justify-end gap-3">
                <button
                  onClick={() => setActiveTest(null)}
                  className="px-4 py-2 text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50"
                >
                  Отмена
                </button>
                <button
                  onClick={() => {
                    // Сохранить результат теста
                    setFormData(prev => ({ ...prev, [testKey]: timer }));
                    setActiveTest(null);
                    resetTimer();
                  }}
                  className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  Сохранить результат
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Функциональные тесты</h2>
      </div>

      <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Выбор спортсмена */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <User className="inline w-4 h-4 mr-1" />
              Выберите спортсмена
            </label>
            <select
              value={selectedAthleteId}
              onChange={(e) => setSelectedAthleteId(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors duration-200"
              required
            >
              <option value="">Выберите спортсмена...</option>
              {mockAthletes.map(athlete => (
                <option key={athlete.id} value={athlete.id}>
                  {athlete.name} - {athlete.sport}
                </option>
              ))}
            </select>
          </div>

          {/* Группы тестов */}
          {testGroups.map((group) => {
            const Icon = group.icon;
            return (
              <div key={group.title} className="space-y-4">
                <div className="flex items-center gap-2 pb-2 border-b border-gray-200">
                  <Icon className={`w-5 h-5 ${group.color}`} />
                  <h3 className="text-lg font-semibold text-gray-900">{group.title}</h3>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {group.fields.map(({ key, label, unit, instruction, interactive, min, max }) => (
                    <div key={key}>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        <div className="flex items-center gap-2">
                          {label}
                          {instruction && (
                            <button
                              type="button"
                              onClick={() => setShowInstructions(instruction)}
                              className="text-blue-500 hover:text-blue-700"
                            >
                              <HelpCircle size={16} />
                            </button>
                          )}
                          {interactive && (
                            <button
                              type="button"
                              onClick={() => setActiveTest(key)}
                              className="text-green-500 hover:text-green-700"
                            >
                              <Play size={16} />
                            </button>
                          )}
                        </div>
                        {min && max && (
                          <div className="text-xs text-gray-500 mt-1">
                            Допустимые значения: {min} - {max} {unit}
                          </div>
                        )}
                      </label>
                      <div className="relative">
                        <input
                          type="number"
                          step="0.1"
                          min={min}
                          max={max}
                          value={formData[key as keyof FunctionalData] || ''}
                          onChange={(e) => handleInputChange(key, e.target.value)}
                          className="w-full px-3 py-2 pr-20 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors duration-200"
                          placeholder="0"
                        />
                        <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 text-xs">
                          {unit}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}

          {/* Кнопки */}
          <div className="flex justify-end gap-3 pt-6 border-t border-gray-100">
            <button
              type="button"
              className="px-4 py-2 text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors duration-200"
              onClick={() => setFormData({})}
            >
              Очистить
            </button>
            <button
              type="submit"
              disabled={!selectedAthleteId}
              className="px-6 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-300 text-white rounded-lg flex items-center gap-2 transition-colors duration-200"
            >
              <Save size={20} />
              Сохранить результаты
            </button>
          </div>
        </form>
      </div>

      {/* Модальные окна */}
      {showInstructions && <InstructionModal testKey={showInstructions} />}
      {activeTest && <InteractiveTestModal testKey={activeTest} />}

      {/* Результаты и аналитика */}
      {selectedAthleteId && (
        <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Анализ функциональных показателей</h3>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {testGroups.slice(0, 3).map((group) => {
              const Icon = group.icon;
              return (
                <div key={group.title} className="h-48 bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg p-4 flex flex-col items-center justify-center">
                  <Icon className={`w-12 h-12 ${group.color} mb-2`} />
                  <p className="text-gray-600 text-sm text-center font-medium">{group.title}</p>
                  <p className="text-xs text-gray-400 text-center mt-1">График показателей</p>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}