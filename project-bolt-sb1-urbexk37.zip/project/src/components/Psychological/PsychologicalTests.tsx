import React, { useState } from 'react';
import { Save, User, Brain, Target, Users, Lightbulb, HelpCircle, CheckCircle, FileText } from 'lucide-react';
import { mockAthletes } from '../../data/mockData';
import { PsychologicalData } from '../../types/athlete';
import { psychologicalQuestionnaires } from '../../data/testInstructions';

export default function PsychologicalTests() {
  const [selectedAthleteId, setSelectedAthleteId] = useState('');
  const [showInstructions, setShowInstructions] = useState<string | null>(null);
  const [activeQuestionnaire, setActiveQuestionnaire] = useState<string | null>(null);
  const [formData, setFormData] = useState<Partial<PsychologicalData>>({
    competitiveAnxiety: 5,
    selfConfidence: 5,
    motivation: 5,
    goalOrientation: 5,
    stressResistance: 5,
    emotionalControl: 5,
    focus: 5,
    resilience: 5,
    teamwork: 5,
    leadership: 5,
    communication: 5,
    adaptability: 5,
    competitiveness: 5,
    riskTaking: 5
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Сохранение психологических данных:', { athleteId: selectedAthleteId, ...formData });
  };

  const psychologicalCategories = [
    {
      title: 'Психологическая готовность',
      icon: Target,
      color: 'text-red-500',
      factors: [
        { key: 'competitiveAnxiety', label: 'Соревновательная тревожность', questionnaire: 'competitive-anxiety' },
        { key: 'selfConfidence', label: 'Уверенность в себе', questionnaire: 'self-confidence' },
        { key: 'motivation', label: 'Мотивация к достижениям', questionnaire: 'sms-motivation' },
        { key: 'goalOrientation', label: 'Целеориентированность' }
      ]
    },
    {
      title: 'Ментальная прочность',
      icon: Brain,
      color: 'text-blue-500',
      factors: [
        { key: 'stressResistance', label: 'Стрессоустойчивость', questionnaire: 'mts-mental-toughness' },
        { key: 'emotionalControl', label: 'Эмоциональный контроль', questionnaire: 'emotional-intelligence' },
        { key: 'focus', label: 'Концентрация внимания', questionnaire: 'cognitive-flexibility' },
        { key: 'resilience', label: 'Устойчивость к неудачам' }
      ]
    },
    {
      title: 'Командное взаимодействие',
      icon: Users,
      color: 'text-green-500',
      factors: [
        { key: 'teamwork', label: 'Командная работа', questionnaire: 'teq-teamwork' },
        { key: 'leadership', label: 'Лидерские качества', questionnaire: 'belbin-team-roles' },
        { key: 'communication', label: 'Коммуникативные навыки' },
        { key: 'adaptability', label: 'Адаптивность' }
      ]
    },
    {
      title: 'Дополнительные качества',
      icon: Lightbulb,
      color: 'text-purple-500',
      factors: [
        { key: 'competitiveness', label: 'Соревновательность' },
        { key: 'riskTaking', label: 'Готовность к риску' }
      ]
    }
  ];

  const getScoreColor = (score: number) => {
    if (score >= 8) return 'text-green-600 bg-green-100';
    if (score >= 6) return 'text-yellow-600 bg-yellow-100';
    return 'text-red-600 bg-red-100';
  };

  const getScoreLabel = (score: number) => {
    if (score >= 8) return 'Высокий';
    if (score >= 6) return 'Средний';
    return 'Низкий';
  };

  const QuestionnaireModal = ({ questionnaireId }: { questionnaireId: string }) => {
    const [answers, setAnswers] = useState<number[]>([]);
    const questionnaire = psychologicalQuestionnaires.find(q => q.id === questionnaireId);
    
    if (!questionnaire) return null;

    const calculateScore = () => {
      let total = 0;
      questionnaire.questions.forEach((question, index) => {
        const answer = answers[index] || 5;
        total += question.reverse ? (11 - answer) : answer;
      });
      const average = total / questionnaire.questions.length;
      
      // Определяем ключ для обновления в зависимости от опросника
      let targetKey = '';
      switch (questionnaireId) {
        case 'competitive-anxiety':
          targetKey = 'competitiveAnxiety';
          break;
        case 'self-confidence':
          targetKey = 'selfConfidence';
          break;
        case 'sms-motivation':
          targetKey = 'motivation';
          break;
        case 'mts-mental-toughness':
          targetKey = 'stressResistance';
          break;
        case 'emotional-intelligence':
          targetKey = 'emotionalControl';
          break;
        case 'cognitive-flexibility':
          targetKey = 'focus';
          break;
        case 'teq-teamwork':
          targetKey = 'teamwork';
          break;
        case 'belbin-team-roles':
          targetKey = 'leadership';
          break;
      }
      
      if (targetKey) {
        setFormData(prev => ({ ...prev, [targetKey]: Math.round(average) }));
      }
      
      setActiveQuestionnaire(null);
      setAnswers([]);
    };

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-xl max-w-2xl w-full max-h-[80vh] overflow-y-auto">
          <div className="p-6">
            <div className="flex justify-between items-start mb-4">
              <h3 className="text-xl font-bold text-gray-900">{questionnaire.name}</h3>
              <button
                onClick={() => setActiveQuestionnaire(null)}
                className="text-gray-400 hover:text-gray-600"
              >
                ✕
              </button>
            </div>
            
            <div className="space-y-4">
              <p className="text-gray-600 mb-6">
                Оцените каждое утверждение по шкале от 1 (совершенно не согласен) до 10 (полностью согласен)
              </p>
              
              {questionnaire.questions.map((question, index) => (
                <div key={question.id} className="p-4 border border-gray-200 rounded-lg">
                  <p className="text-gray-800 mb-3">{index + 1}. {question.text}</p>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-gray-500">1</span>
                    <input
                      type="range"
                      min="1"
                      max="10"
                      value={answers[index] || 5}
                      onChange={(e) => {
                        const newAnswers = [...answers];
                        newAnswers[index] = parseInt(e.target.value);
                        setAnswers(newAnswers);
                      }}
                      className="flex-1 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
                    />
                    <span className="text-sm text-gray-500">10</span>
                    <span className="ml-2 w-8 text-center font-medium text-gray-900">
                      {answers[index] || 5}
                    </span>
                  </div>
                </div>
              ))}
              
              <div className="flex justify-end gap-3 pt-4">
                <button
                  onClick={() => setActiveQuestionnaire(null)}
                  className="px-4 py-2 text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50"
                >
                  Отмена
                </button>
                <button
                  onClick={calculateScore}
                  disabled={answers.length < questionnaire.questions.length}
                  className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-300 flex items-center gap-2"
                >
                  <CheckCircle size={16} />
                  Рассчитать результат
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Психологические тесты</h2>
      </div>

      <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Выбор спортсмена */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <User className="inline w-4 h-4 mr-1" />
              Выберите спортсмена
            </label>
            <select
              value={selectedAthleteId}
              onChange={(e) => setSelectedAthleteId(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors duration-200"
              required
            >
              <option value="">Выберите спортсмена...</option>
              {mockAthletes.map(athlete => (
                <option key={athlete.id} value={athlete.id}>
                  {athlete.name} - {athlete.sport}
                </option>
              ))}
            </select>
          </div>

          {/* Категории психологических факторов */}
          {psychologicalCategories.map((category) => {
            const Icon = category.icon;
            return (
              <div key={category.title} className="space-y-4">
                <div className="flex items-center gap-2 pb-2 border-b border-gray-200">
                  <Icon className={`w-5 h-5 ${category.color}`} />
                  <h3 className="text-lg font-semibold text-gray-900">{category.title}</h3>
                </div>
                
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {category.factors.map((factor) => {
                    const score = formData[factor.key as keyof PsychologicalData] as number || 5;
                    
                    return (
                      <div key={factor.key} className="p-4 border border-gray-200 rounded-lg hover:border-blue-300 transition-all duration-200">
                        <div className="flex items-start gap-3 mb-3">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <h4 className="font-medium text-gray-900">{factor.label}</h4>
                              {factor.questionnaire && (
                                <button
                                  type="button"
                                  onClick={() => setActiveQuestionnaire(factor.questionnaire!)}
                                  className="text-blue-500 hover:text-blue-700"
                                  title="Пройти опросник"
                                >
                                  <FileText size={16} />
                                </button>
                              )}
                            </div>
                          </div>
                          <span className={`px-2 py-1 text-xs rounded-full font-medium ${getScoreColor(score)}`}>
                            {getScoreLabel(score)}
                          </span>
                        </div>
                        
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm text-gray-600">
                            <span>1 (Низкий)</span>
                            <span className="font-medium text-gray-900">{score}/10</span>
                            <span>10 (Высокий)</span>
                          </div>
                          <input
                            type="range"
                            min="1"
                            max="10"
                            value={score}
                            onChange={(e) => setFormData(prev => ({
                              ...prev,
                              [factor.key]: parseInt(e.target.value)
                            }))}
                            className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}

          {/* Кнопки */}
          <div className="flex justify-end gap-3 pt-6 border-t border-gray-100">
            <button
              type="button"
              className="px-4 py-2 text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors duration-200"
              onClick={() => setFormData({
                competitiveAnxiety: 5, selfConfidence: 5, motivation: 5, goalOrientation: 5,
                stressResistance: 5, emotionalControl: 5, focus: 5, resilience: 5,
                teamwork: 5, leadership: 5, communication: 5, adaptability: 5,
                competitiveness: 5, riskTaking: 5
              })}
            >
              Сбросить
            </button>
            <button
              type="submit"
              disabled={!selectedAthleteId}
              className="px-6 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-300 text-white rounded-lg flex items-center gap-2 transition-colors duration-200"
            >
              <Save size={20} />
              Сохранить оценку
            </button>
          </div>
        </form>
      </div>

      {/* Модальные окна */}
      {activeQuestionnaire && <QuestionnaireModal questionnaireId={activeQuestionnaire} />}

      {/* Психологический профиль */}
      {selectedAthleteId && (
        <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Психологический профиль спортсмена</h3>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="h-64 bg-gradient-to-br from-purple-50 to-blue-50 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <Brain size={48} className="text-purple-400 mx-auto mb-2" />
                <p className="text-gray-600">Радиальная диаграмма</p>
                <p className="text-sm text-gray-500 mt-1">Психологических качеств</p>
              </div>
            </div>
            <div className="h-64 bg-gradient-to-br from-green-50 to-teal-50 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <Target size={48} className="text-green-400 mx-auto mb-2" />
                <p className="text-gray-600">Рекомендации</p>
                <p className="text-sm text-gray-500 mt-1">По развитию качеств</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}