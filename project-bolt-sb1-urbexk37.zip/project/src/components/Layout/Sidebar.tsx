import React from 'react';
import { 
  Home, 
  Users, 
  Activity, 
  Brain, 
  Target, 
  TrendingUp, 
  Settings,
  BarChart3
} from 'lucide-react';

interface SidebarProps {
  activeSection: string;
  onSectionChange: (section: string) => void;
}

const menuItems = [
  { id: 'dashboard', label: 'Панель управления', icon: Home },
  { id: 'athletes', label: 'Спортсмены', icon: Users },
  { id: 'physical', label: 'Физические данные', icon: Activity },
  { id: 'functional', label: 'Функциональные тесты', icon: BarChart3 },
  { id: 'psychological', label: 'Психологические тесты', icon: Brain },
  { id: 'performance', label: 'Результаты', icon: Target },
  { id: 'analytics', label: 'Аналитика', icon: TrendingUp },
  { id: 'settings', label: 'Настройки', icon: Settings }
];

export default function Sidebar({ activeSection, onSectionChange }: SidebarProps) {
  return (
    <div className="bg-slate-900 text-white w-64 min-h-screen p-4">
      <div className="mb-8">
        <h1 className="text-xl font-bold text-blue-400">SportAnalytics</h1>
        <p className="text-sm text-slate-400 mt-1">Система спортивного отбора</p>
      </div>
      
      <nav className="space-y-2">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeSection === item.id;
          
          return (
            <button
              key={item.id}
              onClick={() => onSectionChange(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-left transition-all duration-200 ${
                isActive 
                  ? 'bg-blue-600 text-white shadow-lg' 
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <Icon size={20} />
              <span className="text-sm font-medium">{item.label}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
}