import React, { useState } from 'react';
import { Save, User, Ruler, Weight, Activity, Calculator, Info, HelpCircle } from 'lucide-react';
import { mockAthletes } from '../../data/mockData';
import { PhysicalData } from '../../types/athlete';
import { physicalTestInstructions } from '../../data/testInstructions';

export default function PhysicalDataForm() {
  const [selectedAthleteId, setSelectedAthleteId] = useState('');
  const [showInstructions, setShowInstructions] = useState<string | null>(null);
  const [formData, setFormData] = useState<Partial<PhysicalData>>({
    bodyLength: 0,
    bodyLengthSitting: 0,
    bodyMass: 0,
    armSpan: 0,
    legLength: 0,
    shoulderWidth: 0,
    chestCircumference: 0,
    waistCircumference: 0,
    hipCircumference: 0,
    thighCircumference: 0,
    calfCircumference: 0,
    armCircumference: 0,
    forearmCircumference: 0,
    neckCircumference: 0,
    bmiIndex: 0,
    skibinskiIndex: 0,
    pignetIndex: 0,
    erisman: 0
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Сохранение физических данных:', { athleteId: selectedAthleteId, ...formData });
  };

  const calculateBMI = () => {
    if (formData.bodyLength && formData.bodyMass) {
      const heightInMeters = formData.bodyLength / 100;
      const bmi = formData.bodyMass / (heightInMeters * heightInMeters);
      setFormData(prev => ({ ...prev, bmiIndex: Math.round(bmi * 10) / 10 }));
    }
  };

  const calculatePignet = () => {
    if (formData.bodyLength && formData.bodyMass && formData.chestCircumference) {
      const pignet = formData.bodyLength - (formData.bodyMass + formData.chestCircumference);
      setFormData(prev => ({ ...prev, pignetIndex: Math.round(pignet * 10) / 10 }));
    }
  };

  const calculateErisman = () => {
    if (formData.bodyLength && formData.chestCircumference) {
      const erisman = formData.chestCircumference - (formData.bodyLength / 2);
      setFormData(prev => ({ ...prev, erisman: Math.round(erisman * 10) / 10 }));
    }
  };

  const calculateSkibinski = () => {
    // Для расчета нужна ЖЕЛ, используем примерное значение
    if (formData.bodyLength && formData.bodyMass) {
      const estimatedVC = formData.bodyLength * 25; // примерная формула
      const skibinski = (estimatedVC * formData.bodyLength) / formData.bodyMass;
      setFormData(prev => ({ ...prev, skibinskiIndex: Math.round(skibinski * 10) / 10 }));
    }
  };

  const inputGroups = [
    {
      title: 'Основные антропометрические данные',
      icon: Ruler,
      color: 'text-blue-500',
      fields: [
        { key: 'bodyLength', label: 'Длина тела стоя', unit: 'см', instruction: 'bodyLength' },
        { key: 'bodyLengthSitting', label: 'Длина тела сидя', unit: 'см', instruction: 'bodyLengthSitting' },
        { key: 'bodyMass', label: 'Масса тела', unit: 'кг', instruction: 'bodyMass' },
        { key: 'armSpan', label: 'Размах рук', unit: 'см' },
        { key: 'legLength', label: 'Длина ноги', unit: 'см' },
        { key: 'shoulderWidth', label: 'Ширина плеч', unit: 'см' }
      ]
    },
    {
      title: 'Обхватные размеры',
      icon: Weight,
      color: 'text-purple-500',
      fields: [
        { key: 'chestCircumference', label: 'Обхват груди', unit: 'см' },
        { key: 'waistCircumference', label: 'Обхват талии', unit: 'см' },
        { key: 'hipCircumference', label: 'Обхват бедер', unit: 'см' },
        { key: 'thighCircumference', label: 'Обхват бедра', unit: 'см' },
        { key: 'calfCircumference', label: 'Обхват голени', unit: 'см' },
        { key: 'armCircumference', label: 'Обхват плеча', unit: 'см' },
        { key: 'forearmCircumference', label: 'Обхват предплечья', unit: 'см' },
        { key: 'neckCircumference', label: 'Обхват шеи', unit: 'см' }
      ]
    },
    {
      title: 'Интегральные показатели',
      icon: Calculator,
      color: 'text-orange-500',
      fields: [
        { key: 'bmiIndex', label: 'Индекс массы тела', unit: 'кг/м²', calculated: true, calculator: calculateBMI },
        { key: 'pignetIndex', label: 'Индекс Пинье', unit: 'у.е.', calculated: true, calculator: calculatePignet, instruction: 'pignetIndex' },
        { key: 'erisman', label: 'Индекс Эрисмана', unit: 'см', calculated: true, calculator: calculateErisman, instruction: 'erisman' },
        { key: 'skibinskiIndex', label: 'Индекс Скибински', unit: 'у.е.', calculated: true, calculator: calculateSkibinski }
      ]
    }
  ];

  const InstructionModal = ({ testKey }: { testKey: string }) => {
    const instruction = physicalTestInstructions[testKey];
    if (!instruction) return null;

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-xl max-w-2xl w-full max-h-[80vh] overflow-y-auto">
          <div className="p-6">
            <div className="flex justify-between items-start mb-4">
              <h3 className="text-xl font-bold text-gray-900">{instruction.name}</h3>
              <button
                onClick={() => setShowInstructions(null)}
                className="text-gray-400 hover:text-gray-600"
              >
                ✕
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <h4 className="font-semibold text-gray-800 mb-2">Описание:</h4>
                <p className="text-gray-600">{instruction.description}</p>
              </div>
              
              <div>
                <h4 className="font-semibold text-gray-800 mb-2">Необходимое оборудование:</h4>
                <ul className="list-disc list-inside text-gray-600">
                  {instruction.equipment.map((item, index) => (
                    <li key={index}>{item}</li>
                  ))}
                </ul>
              </div>
              
              <div>
                <h4 className="font-semibold text-gray-800 mb-2">Пошаговая инструкция:</h4>
                <ol className="list-decimal list-inside space-y-1 text-gray-600">
                  {instruction.steps.map((step, index) => (
                    <li key={index}>{step}</li>
                  ))}
                </ol>
              </div>
              
              {instruction.norms && (
                <div>
                  <h4 className="font-semibold text-gray-800 mb-2">Нормативы:</h4>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
                    <div className="bg-green-100 p-2 rounded text-center">
                      <div className="font-medium text-green-800">Отлично</div>
                      <div className="text-green-600">{instruction.norms.excellent}</div>
                    </div>
                    <div className="bg-blue-100 p-2 rounded text-center">
                      <div className="font-medium text-blue-800">Хорошо</div>
                      <div className="text-blue-600">{instruction.norms.good}</div>
                    </div>
                    <div className="bg-yellow-100 p-2 rounded text-center">
                      <div className="font-medium text-yellow-800">Средне</div>
                      <div className="text-yellow-600">{instruction.norms.average}</div>
                    </div>
                    <div className="bg-red-100 p-2 rounded text-center">
                      <div className="font-medium text-red-800">Ниже среднего</div>
                      <div className="text-red-600">{instruction.norms.belowAverage}</div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Физические данные и антропометрия</h2>
      </div>

      <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Выбор спортсмена */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <User className="inline w-4 h-4 mr-1" />
              Выберите спортсмена
            </label>
            <select
              value={selectedAthleteId}
              onChange={(e) => setSelectedAthleteId(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors duration-200"
              required
            >
              <option value="">Выберите спортсмена...</option>
              {mockAthletes.map(athlete => (
                <option key={athlete.id} value={athlete.id}>
                  {athlete.name} - {athlete.sport}
                </option>
              ))}
            </select>
          </div>

          {/* Группы измерений */}
          {inputGroups.map((group) => {
            const Icon = group.icon;
            return (
              <div key={group.title} className="space-y-4">
                <div className="flex items-center gap-2 pb-2 border-b border-gray-200">
                  <Icon className={`w-5 h-5 ${group.color}`} />
                  <h3 className="text-lg font-semibold text-gray-900">{group.title}</h3>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {group.fields.map(({ key, label, unit, calculated, instruction, calculator }) => (
                    <div key={key} className="relative">
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        <div className="flex items-center gap-2">
                          {label}
                          {instruction && (
                            <button
                              type="button"
                              onClick={() => setShowInstructions(instruction)}
                              className="text-blue-500 hover:text-blue-700"
                            >
                              <HelpCircle size={16} />
                            </button>
                          )}
                        </div>
                      </label>
                      <div className="relative">
                        <input
                          type="number"
                          step="0.1"
                          value={formData[key as keyof PhysicalData] || ''}
                          onChange={(e) => setFormData(prev => ({
                            ...prev,
                            [key]: parseFloat(e.target.value) || 0
                          }))}
                          className={`w-full px-3 py-2 pr-20 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors duration-200 ${
                            calculated ? 'bg-gray-50' : ''
                          }`}
                          placeholder="0"
                          readOnly={calculated}
                        />
                        <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 text-xs">
                          {unit}
                        </span>
                        {calculated && calculator && (
                          <button
                            type="button"
                            onClick={calculator}
                            className="absolute right-12 top-1/2 transform -translate-y-1/2 text-blue-500 hover:text-blue-700"
                            title="Рассчитать"
                          >
                            <Calculator size={16} />
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}

          {/* Кнопки */}
          <div className="flex justify-end gap-3 pt-6 border-t border-gray-100">
            <button
              type="button"
              className="px-4 py-2 text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors duration-200"
              onClick={() => setFormData({})}
            >
              Очистить
            </button>
            <button
              type="submit"
              disabled={!selectedAthleteId}
              className="px-6 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-300 text-white rounded-lg flex items-center gap-2 transition-colors duration-200"
            >
              <Save size={20} />
              Сохранить данные
            </button>
          </div>
        </form>
      </div>

      {/* Модальное окно с инструкциями */}
      {showInstructions && <InstructionModal testKey={showInstructions} />}

      {/* Визуализация данных */}
      {selectedAthleteId && (
        <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Анализ физических данных</h3>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="h-64 bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <Activity size={48} className="text-blue-400 mx-auto mb-2" />
                <p className="text-gray-600">График композиции тела</p>
                <p className="text-sm text-gray-500 mt-1">ИМТ: {formData.bmiIndex || 0}</p>
              </div>
            </div>
            <div className="h-64 bg-gradient-to-br from-green-50 to-green-100 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <Ruler size={48} className="text-green-400 mx-auto mb-2" />
                <p className="text-gray-600">Антропометрический профиль</p>
                <p className="text-sm text-gray-500 mt-1">Индекс Пинье: {formData.pignetIndex || 0}</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}