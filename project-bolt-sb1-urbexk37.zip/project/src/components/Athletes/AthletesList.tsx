import React, { useState } from 'react';
import { Plus, Search, Filter, Edit, Trash2, User, Eye, Users as UsersIcon } from 'lucide-react';
import { mockAthletes } from '../../data/mockData';
import { Athlete } from '../../types/athlete';

interface AthletesListProps {
  onAthleteSelect?: (athlete: Athlete) => void;
}

export default function AthletesList({ onAthleteSelect }: AthletesListProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSport, setSelectedSport] = useState('');
  const [selectedGender, setSelectedGender] = useState('');
  const [selectedLevel, setSelectedLevel] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [selectedAthlete, setSelectedAthlete] = useState<Athlete | null>(null);
  const [viewMode, setViewMode] = useState<'all' | 'by-sport'>('all');

  const sports = [...new Set(mockAthletes.map(a => a.sport))].sort();
  const levels = [
    { value: 'beginner', label: 'Новичок' },
    { value: 'amateur', label: 'Любитель' },
    { value: 'candidate', label: 'КМС' },
    { value: 'first_class', label: 'I разряд' },
    { value: 'master', label: 'МС' },
    { value: 'international_master', label: 'МСМК' }
  ];
  
  const filteredAthletes = mockAthletes.filter(athlete => {
    const matchesSearch = athlete.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         athlete.sport.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSport = !selectedSport || athlete.sport === selectedSport;
    const matchesGender = !selectedGender || athlete.gender === selectedGender;
    const matchesLevel = !selectedLevel || athlete.sportsLevel === selectedLevel;
    return matchesSearch && matchesSport && matchesGender && matchesLevel;
  });

  const athletesBySport = sports.reduce((acc, sport) => {
    acc[sport] = filteredAthletes.filter(athlete => athlete.sport === sport);
    return acc;
  }, {} as Record<string, Athlete[]>);

  const getLevelLabel = (level: string) => {
    return levels.find(l => l.value === level)?.label || level;
  };

  const getPositionLabel = (sport: string, position?: string) => {
    if (!position) return '';
    
    // Для командных видов спорта - игровое амплуа
    const teamSports = ['Футбол', 'Баскетбол', 'Волейбол', 'Гандбол'];
    if (teamSports.includes(sport)) {
      return `Амплуа: ${position}`;
    }
    
    // Для единоборств - весовая категория
    const combatSports = ['Дзюдо', 'Борьба вольная', 'Борьба греко-римская', 'Самбо'];
    if (combatSports.includes(sport)) {
      return `Категория: ${position}`;
    }
    
    // Для индивидуальных видов - специализация
    return `Специализация: ${position}`;
  };

  const AthleteProfile = ({ athlete }: { athlete: Athlete }) => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-2xl w-full max-h-[80vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex justify-between items-start mb-6">
            <h3 className="text-2xl font-bold text-gray-900">Профиль спортсмена</h3>
            <button
              onClick={() => setSelectedAthlete(null)}
              className="text-gray-400 hover:text-gray-600"
            >
              ✕
            </button>
          </div>
          
          <div className="space-y-6">
            <div className="flex items-center gap-4">
              <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center text-white font-semibold text-2xl">
                {athlete.photo ? (
                  <img src={athlete.photo} alt={athlete.name} className="w-20 h-20 rounded-full object-cover" />
                ) : (
                  <User size={32} />
                )}
              </div>
              <div>
                <h4 className="text-xl font-semibold text-gray-900">{athlete.name}</h4>
                <p className="text-gray-600">{athlete.sport}</p>
                {athlete.position && (
                  <p className="text-sm text-gray-500">{getPositionLabel(athlete.sport, athlete.position)}</p>
                )}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gray-50 p-4 rounded-lg">
                <h5 className="font-medium text-gray-700 mb-2">Основная информация</h5>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Возраст:</span>
                    <span className="font-medium">{athlete.age} лет</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Пол:</span>
                    <span className="font-medium">{athlete.gender === 'male' ? 'Мужской' : 'Женский'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Квалификация:</span>
                    <span className="font-medium">{getLevelLabel(athlete.sportsLevel)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Стаж:</span>
                    <span className="font-medium">{athlete.trainingExperience} лет</span>
                  </div>
                </div>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h5 className="font-medium text-gray-700 mb-2">Даты</h5>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Добавлен:</span>
                    <span className="font-medium">{athlete.createdAt.toLocaleDateString('ru-RU')}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Обновлен:</span>
                    <span className="font-medium">{athlete.updatedAt.toLocaleDateString('ru-RU')}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-3">
              <button
                onClick={() => setSelectedAthlete(null)}
                className="px-4 py-2 text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                Закрыть
              </button>
              <button
                onClick={() => {
                  onAthleteSelect?.(athlete);
                  setSelectedAthlete(null);
                }}
                className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                Выбрать для тестирования
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const AthleteCard = ({ athlete }: { athlete: Athlete }) => (
    <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100 hover:shadow-lg transition-all duration-200">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center text-white font-semibold">
            {athlete.photo ? (
              <img src={athlete.photo} alt={athlete.name} className="w-12 h-12 rounded-full object-cover" />
            ) : (
              <User size={24} />
            )}
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">{athlete.name}</h3>
            <p className="text-sm text-gray-600">{athlete.age} лет • {athlete.gender === 'male' ? 'М' : 'Ж'}</p>
          </div>
        </div>
        <div className="flex gap-2">
          <button 
            onClick={() => setSelectedAthlete(athlete)}
            className="p-2 text-gray-400 hover:text-blue-500 hover:bg-blue-50 rounded-lg transition-all duration-200"
          >
            <Eye size={16} />
          </button>
          <button className="p-2 text-gray-400 hover:text-blue-500 hover:bg-blue-50 rounded-lg transition-all duration-200">
            <Edit size={16} />
          </button>
          <button className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all duration-200">
            <Trash2 size={16} />
          </button>
        </div>
      </div>
      
      <div className="space-y-2">
        <div className="flex justify-between items-center">
          <span className="text-sm text-gray-600">Вид спорта:</span>
          <span className="text-sm font-medium text-gray-900">{athlete.sport}</span>
        </div>
        {athlete.position && (
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-600">Позиция:</span>
            <span className="text-sm font-medium text-gray-900">{athlete.position}</span>
          </div>
        )}
        <div className="flex justify-between items-center">
          <span className="text-sm text-gray-600">Квалификация:</span>
          <span className="text-sm font-medium text-gray-900">{getLevelLabel(athlete.sportsLevel)}</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-sm text-gray-600">Стаж:</span>
          <span className="text-sm font-medium text-gray-900">{athlete.trainingExperience} лет</span>
        </div>
      </div>

      <div className="mt-4 pt-4 border-t border-gray-100">
        <div className="flex gap-2 flex-wrap">
          <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full font-medium">
            {athlete.sport}
          </span>
          <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full font-medium">
            {getLevelLabel(athlete.sportsLevel)}
          </span>
          <span className="px-2 py-1 bg-purple-100 text-purple-800 text-xs rounded-full font-medium">
            {athlete.trainingExperience}г стажа
          </span>
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Спортсмены</h2>
        <div className="flex gap-3">
          <div className="flex bg-gray-100 rounded-lg p-1">
            <button
              onClick={() => setViewMode('all')}
              className={`px-3 py-1 rounded-md text-sm font-medium transition-colors ${
                viewMode === 'all' 
                  ? 'bg-white text-gray-900 shadow-sm' 
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Все спортсмены
            </button>
            <button
              onClick={() => setViewMode('by-sport')}
              className={`px-3 py-1 rounded-md text-sm font-medium transition-colors ${
                viewMode === 'by-sport' 
                  ? 'bg-white text-gray-900 shadow-sm' 
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              По видам спорта
            </button>
          </div>
          <button
            onClick={() => setShowAddForm(true)}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors duration-200"
          >
            <Plus size={20} />
            Добавить спортсмена
          </button>
        </div>
      </div>

      {/* Поиск и фильтры */}
      <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              placeholder="Поиск по имени или виду спорта..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors duration-200"
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Вид спорта</label>
              <select
                value={selectedSport}
                onChange={(e) => setSelectedSport(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="">Все виды спорта</option>
                {sports.map(sport => (
                  <option key={sport} value={sport}>{sport}</option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Пол</label>
              <select
                value={selectedGender}
                onChange={(e) => setSelectedGender(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="">Все</option>
                <option value="male">Мужской</option>
                <option value="female">Женский</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Квалификация</label>
              <select
                value={selectedLevel}
                onChange={(e) => setSelectedLevel(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="">Все уровни</option>
                {levels.map(level => (
                  <option key={level.value} value={level.value}>{level.label}</option>
                ))}
              </select>
            </div>
            
            <div className="flex items-end">
              <button
                onClick={() => {
                  setSearchTerm('');
                  setSelectedSport('');
                  setSelectedGender('');
                  setSelectedLevel('');
                }}
                className="w-full px-3 py-2 text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50 flex items-center justify-center gap-2"
              >
                <Filter size={16} />
                Сбросить
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Отображение спортсменов */}
      {viewMode === 'all' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredAthletes.map((athlete) => (
            <AthleteCard key={athlete.id} athlete={athlete} />
          ))}
        </div>
      ) : (
        <div className="space-y-8">
          {sports.map(sport => {
            const sportAthletes = athletesBySport[sport];
            if (sportAthletes.length === 0) return null;
            
            return (
              <div key={sport} className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
                <div className="flex items-center gap-3 mb-4">
                  <UsersIcon className="w-6 h-6 text-blue-500" />
                  <h3 className="text-xl font-semibold text-gray-900">{sport}</h3>
                  <span className="px-2 py-1 bg-blue-100 text-blue-800 text-sm rounded-full font-medium">
                    {sportAthletes.length}
                  </span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {sportAthletes.map((athlete) => (
                    <AthleteCard key={athlete.id} athlete={athlete} />
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {filteredAthletes.length === 0 && (
        <div className="text-center py-12">
          <User size={48} className="text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500">Спортсмены не найдены</p>
          <p className="text-sm text-gray-400 mt-1">Попробуйте изменить критерии поиска</p>
        </div>
      )}

      {/* Модальное окно профиля */}
      {selectedAthlete && <AthleteProfile athlete={selectedAthlete} />}
    </div>
  );
}