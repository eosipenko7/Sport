import React from 'react';
import { Users, TrendingUp, Target, Activity } from 'lucide-react';
import { mockAthletes, mockPerformanceData } from '../../data/mockData';

const statCards = [
  {
    title: 'Общее количество спортсменов',
    value: mockAthletes.length,
    icon: Users,
    color: 'bg-blue-500',
    change: '+12%'
  },
  {
    title: 'Активные тренировки',
    value: 42,
    icon: Activity,
    color: 'bg-green-500',
    change: '+8%'
  },
  {
    title: 'Соревнования в месяце',
    value: 8,
    icon: Target,
    color: 'bg-orange-500',
    change: '+15%'
  },
  {
    title: 'Средний прогресс',
    value: '87%',
    icon: TrendingUp,
    color: 'bg-purple-500',
    change: '+5%'
  }
];

export default function Dashboard() {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Панель управления</h2>
        <div className="text-sm text-gray-500">
          Последнее обновление: {new Date().toLocaleString('ru-RU')}
        </div>
      </div>

      {/* Статистические карточки */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((card, index) => {
          const Icon = card.icon;
          return (
            <div key={index} className="bg-white rounded-xl shadow-md p-6 border border-gray-100 hover:shadow-lg transition-shadow duration-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 mb-1">{card.title}</p>
                  <p className="text-2xl font-bold text-gray-900">{card.value}</p>
                  <p className="text-sm text-green-600 font-medium">{card.change} за месяц</p>
                </div>
                <div className={`${card.color} p-3 rounded-lg`}>
                  <Icon className="text-white" size={24} />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Последние спортсмены */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Последние добавленные спортсмены</h3>
          <div className="space-y-3">
            {mockAthletes.slice(0, 3).map((athlete) => (
              <div key={athlete.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors duration-200">
                <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center text-white font-semibold">
                  {athlete.name.split(' ').map(n => n[0]).join('')}
                </div>
                <div className="flex-1">
                  <p className="font-medium text-gray-900">{athlete.name}</p>
                  <p className="text-sm text-gray-600">{athlete.sport} • {athlete.age} лет</p>
                </div>
                <div className="text-xs text-gray-500">
                  {athlete.createdAt.toLocaleDateString('ru-RU')}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Последние результаты</h3>
          <div className="space-y-3">
            {mockPerformanceData.slice(0, 3).map((performance) => {
              const athlete = mockAthletes.find(a => a.id === performance.athleteId);
              return (
                <div key={performance.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors duration-200">
                  <div>
                    <p className="font-medium text-gray-900">{athlete?.name}</p>
                    <p className="text-sm text-gray-600">{performance.competitionName}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-blue-600">#{performance.ranking}</p>
                    <p className="text-xs text-gray-500">из {performance.totalParticipants}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* График прогресса */}
      <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Динамика результатов</h3>
        <div className="h-64 bg-gradient-to-r from-blue-50 to-green-50 rounded-lg flex items-center justify-center">
          <div className="text-center">
            <TrendingUp size={48} className="text-blue-400 mx-auto mb-2" />
            <p className="text-gray-600">График будет отображаться здесь</p>
            <p className="text-sm text-gray-500">Интерактивная аналитика результатов спортсменов</p>
          </div>
        </div>
      </div>
    </div>
  );
}