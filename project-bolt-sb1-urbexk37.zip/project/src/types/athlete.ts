export interface Athlete {
  id: string;
  name: string;
  age: number;
  gender: 'male' | 'female';
  sport: string;
  position?: string; // Спортивная ориентация/амплуа
  sportsLevel: 'beginner' | 'amateur' | 'candidate' | 'first_class' | 'master' | 'international_master';
  trainingExperience: number; // лет
  photo?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface PhysicalData {
  id: string;
  athleteId: string;
  // Основные антропометрические данные
  bodyLength: number; // длина тела стоя, см
  bodyLengthSitting: number; // длина тела сидя, см
  bodyMass: number; // масса тела, кг
  armSpan: number; // размах рук, см
  legLength: number; // длина ноги, см
  shoulderWidth: number; // ширина плеч, см
  // Обхватные размеры
  chestCircumference: number; // обхват груди, см
  waistCircumference: number; // обхват талии, см
  hipCircumference: number; // обхват бедер, см
  thighCircumference: number; // обхват бедра, см
  calfCircumference: number; // обхват голени, см
  armCircumference: number; // обхват плеча, см
  forearmCircumference: number; // обхват предплечья, см
  neckCircumference: number; // обхват шеи, см
  // Интегральные показатели
  bmiIndex: number; // индекс массы тела
  skibinskiIndex: number; // индекс Скибински
  pignetIndex: number; // индекс Пинье
  erisman: number; // индекс Эрисмана
  recordedAt: Date;
}

export interface FunctionalData {
  id: string;
  athleteId: string;
  // Кардиореспираторные показатели
  vo2Max: number; // мл/кг/мин
  restingHeartRate: number; // ЧСС покоя, уд/мин
  vitalCapacity: number; // жизненная емкость легких, мл
  breathHoldInhale: number; // задержка дыхания на вдохе (проба Штанге), сек
  breathHoldExhale: number; // задержка дыхания на выдохе (проба Генча), сек
  // Функциональные пробы
  rufierIndex: number; // проба Руфье
  martineTest: number; // проба Мартине, мин восстановления
  orthostatic: number; // ортостатическая проба, разность ЧСС
  harvardStepTest: number; // Гарвардский степ-тест, индекс
  pwc150: number; // PWC150 для детей, кгм/мин
  pwc170: number; // PWC170, кгм/мин
  // Скоростно-силовые качества
  sprint30m: number; // бег 30м, сек
  sprint60m: number; // бег 60м, сек
  sprint100m: number; // бег 100м, сек
  standingLongJump: number; // прыжок в длину с места, см
  verticalJump: number; // прыжок вверх, см
  // Силовые качества
  handGripStrength: number; // сила кисти, кг
  backStrength: number; // сила спины, кг
  legStrength: number; // сила ног, кг
  // Силовая выносливость
  pullUpsBar: number; // подтягивание в висе на перекладине, раз
  hangTime: number; // вис на согнутых руках, сек
  sitUps: number; // поднимание туловища из положения лежа на спине, раз/мин
  pushUps: number; // сгибание-разгибание рук в упоре лежа, раз
  plankTime: number; // планка, сек
  // Гибкость
  sitAndReach: number; // наклон вперед из положения сидя, см
  shoulderFlexibility: number; // подвижность плечевых суставов, см
  spineFlexibility: number; // гибкость позвоночника, см
  // Координация и ловкость
  shuttleRun4x9: number; // челночный бег 4×9м, сек
  balanceTest: number; // проба Ромберга, сек
  reactionTime: number; // время реакции, мс
  // Выносливость
  cooper6min: number; // 6-минутный бег, м
  cooper12min: number; // тест Купера 12 мин, м
  run500m: number; // бег 500м, мин:сек
  run800m: number; // бег 800м, мин:сек
  run1000m: number; // бег 1000м, мин:сек
  run1500m: number; // бег 1500м, мин:сек
  run3000m: number; // бег 3000м, мин:сек
  recordedAt: Date;
}

export interface PsychologicalData {
  id: string;
  athleteId: string;
  // Психологическая готовность
  competitiveAnxiety: number; // соревновательная тревожность (1-10)
  selfConfidence: number; // уверенность в себе (1-10)
  motivation: number; // мотивация к достижениям (1-10)
  goalOrientation: number; // целеориентированность (1-10)
  // Ментальная прочность
  stressResistance: number; // стрессоустойчивость (1-10)
  emotionalControl: number; // эмоциональный контроль (1-10)
  focus: number; // концентрация внимания (1-10)
  resilience: number; // устойчивость к неудачам (1-10)
  // Командное взаимодействие
  teamwork: number; // командная работа (1-10)
  leadership: number; // лидерские качества (1-10)
  communication: number; // коммуникативные навыки (1-10)
  adaptability: number; // адаптивность (1-10)
  // Дополнительные качества
  competitiveness: number; // соревновательность (1-10)
  riskTaking: number; // готовность к риску (1-10)
  recordedAt: Date;
}

export interface PerformanceData {
  id: string;
  athleteId: string;
  competitionName: string;
  result: number;
  ranking: number;
  totalParticipants: number;
  date: Date;
  notes?: string;
}

export interface PredictionModel {
  athleteId: string;
  predictedPerformance: number;
  confidence: number; // 0-1
  keyFactors: Array<{
    factor: string;
    impact: number; // -1 to 1
    category: 'physical' | 'functional' | 'psychological';
  }>;
  recommendations: string[];
}

export interface TestInstruction {
  name: string;
  description: string;
  equipment: string[];
  steps: string[];
  measurement: string;
  norms?: {
    excellent: number;
    good: number;
    average: number;
    belowAverage: number;
  };
}

export interface FunctionalTestSession {
  id: string;
  athleteId: string;
  testType: string;
  currentStep: number;
  stepData: Record<string, any>;
  isCompleted: boolean;
  startTime: Date;
  endTime?: Date;
}

export interface PsychologicalQuestionnaire {
  id: string;
  name: string;
  category: 'readiness' | 'mental_toughness' | 'team_interaction';
  questions: Array<{
    id: string;
    text: string;
    type: 'scale' | 'choice';
    options?: string[];
    reverse?: boolean; // для обратных вопросов
  }>;
  scoring: {
    min: number;
    max: number;
    interpretation: Record<string, string>;
  };
}